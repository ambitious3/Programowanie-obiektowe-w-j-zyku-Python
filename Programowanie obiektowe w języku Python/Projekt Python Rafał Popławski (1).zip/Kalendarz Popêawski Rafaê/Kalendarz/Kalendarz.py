wybor = -1          #definiowanie zmiennych

wydarzenia = []

daty = []

godziny = []

cale = []
 # Wyżej mamy zamieszczone listy

def pokaz_wyd():                    #funkcja mająca zadanie wyświetlić wydarzenia
    indeks = 0
    for lacz in cale:
        print( " [" + str(indeks) + "]  " + lacz )
        indeks += 1

def dodaj_wyd():                    #funkcja mająca zadanie dodania wydarzenia
    nazwa = input("Title: ")
    wydarzenia.append(nazwa)                

    data = input("Date (DD.MM.YYYY): ")
    daty.append(data)

    godzina = input ("Time (HH:MM):")
    godziny.append(godzina)

    lacz = nazwa + "-" + data + "-" + godzina           #łączenie w jedną, główną listę
    cale.append(lacz)
    print("Success!")

def usun_wyd():                 #funkcja mająca zadanie usunąć wydarzenie
    indeks = int(input("Wchich one you want to delete: "))

    if indeks < 0 or indeks > len(cale) - 1:           #pętla mająca zadanie usunąć indeks
        print("Event doesn't exist!")
        return
    cale.pop(indeks)
    print("Event deleted!")

def zapisz_wyd():                   #funkcja mająca zadanie zapisać wydarzenie
    file = open("cale.txt", "w+")
    for lacz in cale:
        file.write(lacz+"\n")
    file.close()
    print("Event is saved!")

def wczytaj_wyd():          #funkcja mająca zadanie wczytywanie wydarzeń do aplikacji
    try:                    #blokada przeciwko zatrzymaniu się aplikacji z powodu błędu wynikającego z braku aplikacji (definiowanie wyjątków)
        file = open("cale.txt")

        for line in file.readlines():
            cale.append(line.strip())
        file.close()
    except FileNotFoundError:
        return

def zapisz_ical():                                      #zapisywanie wydarzeń w formie icalendar
     file = open("cale.txt", "w+")
     for lacz in cale:
         file.write(lacz+"\n")
     file.close()
     print("Event is saved!")

wczytaj_wyd()

while wybor != 6:                   #pętla która ma za zadanie wyświetlać stale liste do wyboru
    if wybor == 1:
       pokaz_wyd()

    if wybor == 2:
        dodaj_wyd() 
        print ()
                                    #warunki
    if wybor == 3:
        usun_wyd()

    if wybor == 4:
        zapisz_wyd()

    if wybor == 5:
        zapisz_ical()

    print("1. List Calendar")
    print("2. Add Event")
    print("3. Delete Event")
    print("4. Save Changes")
    print("5. Export calendar to Icalendar")
    print("6. Exit")

    print()

    wybor = int(input("Select menu item (1-6): "))
    print()

    # dzien = int(input("Day:"))
    # if dzien < 1 or dzien >30:
    #     print("Invalid input!")
    #     return
    # dni.append(dzien)
    # miesiac = int(input("Month:"))
    # if miesiac < 1 or miesiac > 12:
    #     print("Invalid input!")
    #     return
    # rok = int(input("Year:"))
    # if rok < 1 or rok > 2999:
    #     print("Invalid input!")
    #     return
    #
    # miesiace.append(miesiac)
    # lata.append(rok)